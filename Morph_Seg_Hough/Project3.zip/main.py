import Task1.Task1 as t1
import Task2.Task2 as t2
import Task3.Task3 as t3
import Task3.Task3Bonus as t3b

t1.Task1Handler()
t2.Task2Handler()
t3.Task3Handler()
t3b.Task3BonusHandler()