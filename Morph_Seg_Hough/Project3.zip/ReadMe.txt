UBITName: rthosar
Email: rthosar@buffalo.edu

1. The project is structured according to tasks. That is, the directories, Task1, Task2, Task3 contain respective modules required to execute the tasks.
2. All of the source images are stored in InputData directory and are accessed from the same location.
3. You just have to run the "main.py" file. It internally calls all the tasks' modules.
4. The output images of the tasks are stored in OutputData directory.

Feel free to contact me on the above mentioned email if any further explanation is needed.